package com.anusha.resume_builder.resume.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ResumeParserService {

    private static final Logger log = LoggerFactory.getLogger(ResumeParserService.class);

    @Value("${gemini.api.key:}")
    private String geminiApiKey;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(25))
            .build();

    private static final List<String> CANDIDATE_MODELS = List.of(
            "gemini-2.5-flash",
            "gemini-1.5-flash"
    );

    public Map<String, Object> parseResumeFile(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Uploaded file cannot be empty.");
        }

        String fileName = file.getOriginalFilename() != null ? file.getOriginalFilename().toLowerCase() : "";
        String extractedText = "";

        if (fileName.endsWith(".pdf")) {
            try (PDDocument document = Loader.loadPDF(file.getBytes())) {
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                extractedText = stripper.getText(document);
            }
        } else {
            extractedText = new String(file.getBytes(), StandardCharsets.UTF_8);
        }

        if (extractedText.trim().isEmpty()) {
            throw new IllegalArgumentException("No text could be extracted from this document.");
        }

        String prompt = """
            You are an expert technical ATS resume parser.
            Convert the resume text into strict, valid JSON matching this exact structure:
            {
              "name": "Candidate Full Name",
              "role": "Current Job Title or Specialization",
              "personal": {
                "fullName": "Candidate Full Name",
                "email": "Email address",
                "phone": "Phone number",
                "location": "City, Country",
                "linkedin": "LinkedIn URL",
                "github": "GitHub URL",
                "website": "Portfolio URL"
              },
              "summary": "Professional summary or career objective text",
              "education": [
                {
                  "institution": "University / College name",
                  "degree": "Degree (e.g. B.E. in Computer Science)",
                  "field": "Specialization or Major",
                  "startDate": "Start year/date",
                  "endDate": "End year/date",
                  "grade": "CGPA or percentage"
                }
              ],
              "internships": [
                {
                  "role": "Role title",
                  "company": "Company name",
                  "location": "Location",
                  "startDate": "Start date",
                  "endDate": "End date",
                  "description": "• Bullet 1\\n• Bullet 2"
                }
              ],
              "experience": [
                {
                  "role": "Role title",
                  "company": "Company name",
                  "location": "Location",
                  "startDate": "Start date",
                  "endDate": "End date",
                  "description": "• Bullet 1\\n• Bullet 2"
                }
              ],
              "projects": [
                {
                  "name": "Project name",
                  "technologies": "Languages and tools used",
                  "link": "Project link or GitHub URL",
                  "description": "• Bullet 1\\n• Bullet 2"
                }
              ],
              "skills": {
                "Languages": ["Java", "SQL"],
                "Frameworks & Tools": ["Spring Boot", "Git"],
                "Databases": ["PostgreSQL"]
              },
              "certifications": [
                {
                  "name": "Certification title",
                  "issuer": "Issuing organization",
                  "date": "Year"
                }
              ],
              "languages": [
                {
                  "name": "Language name",
                  "proficiency": "Fluent"
                }
              ]
            }

            STRICT RULES:
            1. Return ONLY the raw JSON object.
            2. Do NOT include markdown formatting like ```json.
            3. Populate both "name" and "personal.fullName" with the candidate's actual name.

            Resume Text:
            \"\"\"
            """ + extractedText + """
            \"\"\"
            """;

        String cleanKey = sanitizeApiKey(geminiApiKey);

        if (!cleanKey.isEmpty()) {
            for (String modelName : CANDIDATE_MODELS) {
                try {
                    String raw = callGemini(modelName, prompt, cleanKey);
                    String cleanJson = raw
                            .replaceAll("(?s)^```[a-zA-Z]*\\s*", "")
                            .replaceAll("```\\s*$", "")
                            .trim();

                    return objectMapper.readValue(cleanJson, new TypeReference<Map<String, Object>>() {});
                } catch (Exception ex) {
                    log.warn("Gemini model [{}] failed: {}. Trying fallback...", modelName, ex.getMessage());
                }
            }
        }

        log.warn("All Gemini parsing calls failed. Employing local regex fallback.");
        return localExtractionFallback(extractedText, fileName);
    }

    public Map<String, String> enhanceText(String type, String currentText, String jobRole, String context) {
        if (currentText == null || currentText.trim().isEmpty()) {
            return Map.of("enhancedText", "");
        }

        String safeRole = (jobRole != null && !jobRole.trim().isEmpty()) ? jobRole.trim() : "Software Engineer";
        String prompt;

        if ("summary".equalsIgnoreCase(type)) {
            prompt = String.format("""
                Rewrite this professional summary for a %s into ONE cohesive, impactful paragraph (2-4 sentences).
                Draft: "%s"
                Return ONLY the rewritten paragraph without quotes or commentary.
                """, safeRole, currentText.trim());
        } else {
            prompt = String.format("""
                Rewrite the following bullet points for a %s (Context: %s).
                Draft: "%s"
                Rules:
                1. Output 2-3 strong bullet points, each starting with "• ".
                2. Use strong action verbs (Developed, Optimized, Engineered).
                3. Return ONLY the bullets without intro text or quotes.
                """, safeRole, context != null ? context : "", currentText.trim());
        }

        String cleanKey = sanitizeApiKey(geminiApiKey);

        if (!cleanKey.isEmpty()) {
            for (String modelName : CANDIDATE_MODELS) {
                try {
                    String enhanced = callGemini(modelName, prompt, cleanKey);
                    String clean = enhanced
                            .replaceAll("(?s)^```[a-zA-Z]*\\s*", "")
                            .replaceAll("```\\s*$", "")
                            .replaceAll("(?i)^(Here (is|are) (the|an)? enhanced.*?:\\s*)", "")
                            .replaceAll("^\"|\"$", "")
                            .trim();
                    return Map.of("enhancedText", clean);
                } catch (Exception ignored) {}
            }
        }

        return Map.of("enhancedText", currentText);
    }

    private String callGemini(String model, String prompt, String apiKey) throws Exception {
        // Construct standard URL with clean strings
        String endpoint = "[https://generativelanguage.googleapis.com/v1beta/models/](https://generativelanguage.googleapis.com/v1beta/models/)" + model.trim() + ":generateContent?key=" + apiKey.trim();
        URI uri = new URI("https", "generativelanguage.googleapis.com", "/v1beta/models/" + model.trim() + ":generateContent", "key=" + apiKey.trim(), null);

        Map<String, Object> body = Map.of(
                "contents", List.of(
                        Map.of("parts", List.of(Map.of("text", prompt)))
                )
        );

        String jsonPayload = objectMapper.writeValueAsString(body);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(20))
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        }

        Map<String, Object> respMap = objectMapper.readValue(response.body(), new TypeReference<>() {});
        List<?> candidates = (List<?>) respMap.get("candidates");
        if (candidates == null || candidates.isEmpty()) {
            throw new IOException("No candidates returned from Gemini");
        }

        Map<?, ?> firstCandidate = (Map<?, ?>) candidates.get(0);
        Map<?, ?> content = (Map<?, ?>) firstCandidate.get("content");
        List<?> parts = (List<?>) content.get("parts");
        return (String) ((Map<?, ?>) parts.get(0)).get("text");
    }

    private String sanitizeApiKey(String key) {
        if (key == null) return "";
        // Clean out any accidental markdown syntax [url](url), quotes, brackets, or leading spaces
        String cleaned = key.replaceAll("[\\[\\]()\"'\\s]", "").trim();
        if (cleaned.contains("key=")) {
            cleaned = cleaned.substring(cleaned.lastIndexOf("key=") + 4);
        }
        return cleaned;
    }

    private Map<String, Object> localExtractionFallback(String text, String fileName) {
        Map<String, Object> map = new HashMap<>();
        String name = fileName.replaceFirst("(?i)\\.(pdf|docx|txt)$", "").replace("-", " ").replace("_", " ").trim();
        map.put("name", name.isEmpty() ? "Imported Resume" : name);
        map.put("role", "Software Engineer");

        Map<String, Object> personal = new HashMap<>();
        Matcher emailM = Pattern.compile("(?i)[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}").matcher(text);
        personal.put("email", emailM.find() ? emailM.group() : "");

        Matcher phoneM = Pattern.compile("(?:\\+?\\d{1,3}[-.\\s]?)?\\(?\\d{3}\\)?[-.\\s]?\\d{3}[-.\\s]?\\d{4}").matcher(text);
        personal.put("phone", phoneM.find() ? phoneM.group() : "");

        String[] lines = text.split("\\r?\\n");
        String firstLine = "";
        for (String line : lines) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty() && trimmed.length() < 35 && !trimmed.contains("@")) {
                firstLine = trimmed;
                break;
            }
        }
        personal.put("fullName", firstLine.isEmpty() ? "Candidate Name" : firstLine);
        personal.put("location", "");
        personal.put("linkedin", "");
        personal.put("github", "");
        personal.put("website", "");
        map.put("personal", personal);

        map.put("summary", "");
        map.put("education", new ArrayList<>());
        map.put("internships", new ArrayList<>());
        map.put("experience", new ArrayList<>());
        map.put("projects", new ArrayList<>());

        Map<String, Object> skills = new HashMap<>();
        skills.put("Languages", List.of());
        skills.put("Frameworks & Tools", List.of());
        skills.put("Databases", List.of());
        map.put("skills", skills);

        map.put("certifications", new ArrayList<>());
        map.put("achievements", new ArrayList<>());
        map.put("languages", new ArrayList<>());

        return map;
    }
}