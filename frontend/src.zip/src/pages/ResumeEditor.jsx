import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Save,
  ChevronLeft,
  ArrowRight,
  ArrowLeft,
  SkipForward,
  Sparkles,
  Plus,
  Trash2,
  Layout,
  Check,
  AlertCircle,
  Loader2,
  FileText,
  Briefcase,
  GraduationCap,
  FolderGit2,
  Award,
  Code2,
  Trophy,
  Users,
  Languages,
  Eye,
  Columns,
  Edit3,
  Download,
} from "lucide-react";
import ResumePreview from "../components/preview/ResumePreview";
import { getResume, createResume, updateResume } from "../api/resumeApi";
import { getToken } from "../utils/auth";
import "./ResumeEditor.css";

const COLOR_OPTIONS = [
  { name: "Slate", hex: "#0f172a" },
  { name: "Navy", hex: "#1e3a8a" },
  { name: "Indigo", hex: "#4338ca" },
  { name: "Teal", hex: "#0f766e" },
  { name: "Emerald", hex: "#047857" },
  { name: "Ruby", hex: "#991b1b" },
];

const TEMPLATE_OPTIONS = [
  { id: "emma", label: "Modern Standard (Emma)" },
  { id: "aaditya", label: "Technical / Data Analyst" },
  { id: "executive", label: "Executive Header" },
  { id: "harvard", label: "Harvard Classic" },
  { id: "minimal", label: "Minimalist Clean" },
];

const SECTIONS = [
  { id: "personal", label: "Personal", icon: FileText },
  { id: "summary", label: "Summary", icon: Sparkles },
  { id: "skills", label: "Skills", icon: Code2 },
  { id: "education", label: "Education", icon: GraduationCap },
  { id: "internships", label: "Internships", icon: Briefcase },
  { id: "experience", label: "Experience", icon: Briefcase },
  { id: "projects", label: "Projects", icon: FolderGit2 },
  { id: "certifications", label: "Certifications", icon: Award },
  { id: "achievements", label: "Achievements", icon: Trophy },
  { id: "involvement", label: "Involvement", icon: Users },
  { id: "languages", label: "Languages", icon: Languages },
];

const DEFAULT_RESUME = {
  name: "My Resume",
  role: "Software Engineer",
  template: "emma",
  color: "#0f172a",
  primaryColor: "#0f172a",
  personal: {
    fullName: "",
    email: "",
    phone: "",
    location: "",
    linkedin: "",
    github: "",
    website: "",
  },
  summary: "",
  skills: {
    Languages: [],
    "Frameworks & Tools": [],
    Databases: [],
  },
  education: [],
  internships: [],
  experience: [],
  projects: [],
  certifications: [],
  achievements: [],
  involvement: [],
  languages: [],
};

export default function ResumeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const printRef = useRef(null);

  const [resume, setResume] = useState(DEFAULT_RESUME);
  const [currentStep, setCurrentStep] = useState(0);
  const [viewMode, setViewMode] = useState("both"); // "form" | "both" | "preview"
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(Boolean(id));
  const [enhancing, setEnhancing] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const [skillInputs, setSkillInputs] = useState({
    Languages: "",
    "Frameworks & Tools": "",
    Databases: "",
  });

  useEffect(() => {
    async function init() {
      if (id) {
        try {
          setLoading(true);
          const data = await getResume(id);
          let parsed = {};

          if (typeof data.resumeData === "string") {
            try {
              parsed = JSON.parse(data.resumeData);
            } catch {
              parsed = {};
            }
          } else if (typeof data.resumeData === "object" && data.resumeData !== null) {
            parsed = data.resumeData;
          }

          const merged = {
            ...DEFAULT_RESUME,
            ...parsed,
            name: data.name || parsed.name || "My Resume",
            role: data.role || parsed.role || "Software Engineer",
            template: data.template || parsed.template || "emma",
            color: data.color || data.primaryColor || parsed.color || "#0f172a",
            primaryColor: data.color || data.primaryColor || parsed.color || "#0f172a",
            personal: {
              ...DEFAULT_RESUME.personal,
              ...(parsed.personal || {}),
            },
          };

          setResume(merged);
          syncSkills(merged.skills);
        } catch (err) {
          setError("Failed to load resume: " + err.message);
        } finally {
          setLoading(false);
        }
      } else {
        const imported = sessionStorage.getItem("importedResumeData");
        const pendingName = sessionStorage.getItem("pendingResumeName");
        const pendingRole = sessionStorage.getItem("pendingResumeRole");

        if (imported) {
          try {
            const parsed = JSON.parse(imported);
            const initial = {
              ...DEFAULT_RESUME,
              ...parsed,
              name: pendingName || parsed.name || "My Resume",
              role: pendingRole || parsed.role || "Software Engineer",
              personal: {
                ...DEFAULT_RESUME.personal,
                ...(parsed.personal || {}),
              },
            };
            setResume(initial);
            syncSkills(initial.skills);
          } catch (e) {
            console.error("Failed to parse imported resume:", e);
          }
        } else {
          // Fresh blank resume
          setResume(DEFAULT_RESUME);
          syncSkills({});
        }
      }
    }

    init();
  }, [id]);

  function syncSkills(skillsObj = {}) {
    setSkillInputs({
      Languages: Array.isArray(skillsObj["Languages"]) ? skillsObj["Languages"].join(", ") : "",
      "Frameworks & Tools": Array.isArray(skillsObj["Frameworks & Tools"])
        ? skillsObj["Frameworks & Tools"].join(", ")
        : "",
      Databases: Array.isArray(skillsObj["Databases"]) ? skillsObj["Databases"].join(", ") : "",
    });
  }

  const handlePersonalChange = (field, value) => {
    setResume((prev) => ({
      ...prev,
      personal: {
        ...prev.personal,
        [field]: value,
      },
    }));
  };

  const handleArrayItemChange = (section, index, field, value) => {
    setResume((prev) => {
      const arr = [...(prev[section] || [])];
      arr[index] = { ...arr[index], [field]: value };
      return { ...prev, [section]: arr };
    });
  };

  const addArrayItem = (section, template) => {
    setResume((prev) => ({
      ...prev,
      [section]: [...(prev[section] || []), template],
    }));
  };

  const removeArrayItem = (section, index) => {
    setResume((prev) => ({
      ...prev,
      [section]: (prev[section] || []).filter((_, i) => i !== index),
    }));
  };

  const handleSkillChange = (category, value) => {
    setSkillInputs((prev) => ({ ...prev, [category]: value }));
    const arr = value
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    setResume((prev) => ({
      ...prev,
      skills: {
        ...(prev.skills || {}),
        [category]: arr,
      },
    }));
  };

  // AI Enhance API call
  const handleAiEnhance = async (type, currentText, callback, context = "") => {
    if (!currentText || !currentText.trim()) {
      setError("Please write some draft text first to enhance.");
      return;
    }

    setEnhancing(true);
    setError("");

    try {
      const token = localStorage.getItem("token") || getToken();
      const res = await fetch("http://localhost:8080/api/resumes/ai-enhance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token.trim()}` } : {}),
        },
        body: JSON.stringify({
          type,
          text: currentText,
          role: resume.role || "Software Engineer",
          context,
        }),
      });

      if (!res.ok) {
        throw new Error("AI enhance request failed.");
      }

      const data = await res.json();
      if (data?.enhancedText) {
        callback(data.enhancedText);
        setSuccessMsg("Text enhanced with AI!");
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    } catch (err) {
      setError(err.message || "Failed to enhance with AI.");
    } finally {
      setEnhancing(false);
    }
  };

  const handleSave = async (showToast = true) => {
    setSaving(true);
    setError("");
    if (showToast) setSuccessMsg("");

    try {
      const currentColor = resume.color || resume.primaryColor || "#0f172a";
      const payload = {
        name: resume.name || "My Resume",
        role: resume.role || "Software Engineer",
        template: resume.template || "emma",
        color: currentColor,
        primaryColor: currentColor,
        resumeData: JSON.stringify(resume),
      };

      if (id) {
        await updateResume(id, payload);
        if (showToast) setSuccessMsg("Resume saved successfully!");
      } else {
        const created = await createResume(payload);
        sessionStorage.removeItem("importedResumeData");
        sessionStorage.removeItem("pendingResumeName");
        sessionStorage.removeItem("pendingResumeRole");

        if (showToast) setSuccessMsg("Resume created successfully!");
        if (created?.id) {
          navigate(`/editor/${created.id}`, { replace: true });
        }
      }

      if (showToast) setTimeout(() => setSuccessMsg(""), 3000);
    } catch (err) {
      setError(err.message || "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) setCurrentStep((prev) => prev - 1);
  };

  const handleSkip = () => {
    if (currentStep < SECTIONS.length - 1) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleNext = async () => {
    await handleSave(false);
    if (currentStep < SECTIONS.length - 1) {
      setCurrentStep((prev) => prev + 1);
    } else {
      setSuccessMsg("All sections saved successfully!");
      setTimeout(() => setSuccessMsg(""), 3000);
    }
  };

  if (loading) {
    return (
      <div className="editor-loading-screen">
        <Loader2 className="spinner-icon" size="{32}"/>
        <p>Loading resume editor...</p>
      </div>
    );
  }

  return (
    <div className="res-editor-shell">
      {/* NAVBAR */}
      <header className="res-top-navbar">
        <div className="res-nav-left">
          <button type="button" className="btn-nav-back" onClick={() => navigate("/dashboard")}>
            <ChevronLeft size="{16}"/>
            <span>Dashboard</span>
          </button>
          <div className="res-meta-titles">
            <input
              type="text"
              className="meta-title-input"
              value={resume.name || ""}
              onChange={(e) => setResume((prev) => ({ ...prev, name: e.target.value }))}
              placeholder="Resume Name"
            />
            <input
              type="text"
              className="meta-role-input"
              value={resume.role || ""}
              onChange={(e) => setResume((prev) => ({ ...prev, role: e.target.value }))}
              placeholder="Target Role"
            />
          </div>
        </div>

        {/* VIEW MODE TOGGLE */}
        <div className="res-nav-center">
          <div className="view-mode-pill">
            <button
              type="button"
              className={`pill-btn ${viewMode === "form" ? "active" : ""}`}
              onClick={() => setViewMode("form")}
            >
              <Edit3 size="{14}"/>
              <span>Form</span>
            </button>
            <button
              type="button"
              className={`pill-btn ${viewMode === "both" ? "active" : ""}`}
              onClick={() => setViewMode("both")}
            >
              <Columns size="{14}"/>
              <span>Both</span>
            </button>
            <button
              type="button"
              className={`pill-btn ${viewMode === "preview" ? "active" : ""}`}
              onClick={() => setViewMode("preview")}
            >
              <Eye size="{14}"/>
              <span>Preview</span>
            </button>
          </div>
        </div>

        {/* TEMPLATE, COLOR, DOWNLOAD & SAVE */}
        <div className="res-nav-right">
          <div className="select-template-wrap">
            <Layout size="{14}"/>
            <select
              value={resume.template || "emma"}
              onChange={(e) => setResume((prev) => ({ ...prev, template: e.target.value }))}
            >
              {TEMPLATE_OPTIONS.map((t) => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </div>

          <div className="theme-color-dots">
            {COLOR_OPTIONS.map((c) => {
              const active = (resume.color || resume.primaryColor) === c.hex;
              return (
                <button
                  key={c.hex}
                  type="button"
                  className={`color-bubble ${active ? "active" : ""}`}
                  style={{ backgroundColor: c.hex }}
                  onClick={() => setResume((prev) => ({ ...prev, color: c.hex, primaryColor: c.hex }))}
                  title={c.name}
                >
                  {active && <Check color="#ffffff" size="{10}"/>}
                </button>
              );
            })}
          </div>

          <button type="button" className="btn-nav-action download-btn" onClick={() => window.print()}>
            <Download size="{15}"/>
            <span>Download</span>
          </button>

          <button type="button" className="btn-nav-action save-btn" disabled={saving} onClick={() => handleSave(true)}>
            {saving ? <Loader2 className="spinner-icon" size="{15}"/> : <Save size="{15}"/>}
            <span>{saving ? "Saving..." : "Save"}</span>
          </button>
        </div>
      </header>

      {/* TOAST ALERTS */}
      {error && (
        <div className="editor-toast-alert toast-error">
          <AlertCircle size="{15}"/>
          <span>{error}</span>
        </div>
      )}
      {successMsg && (
        <div className="editor-toast-alert toast-success">
          <Check size="{15}"/>
          <span>{successMsg}</span>
        </div>
      )}

      {/* WORKSPACE GRID */}
      <div className={`res-editor-grid view-${viewMode}`}>
        {/* LEFT COLUMN: FORM WIZARD */}
        {(viewMode === "form" || viewMode === "both") && (
          <div className="res-form-column">
            {/* 11 SECTIONS TABS */}
            <div className="res-sections-nav-scroll">
              {SECTIONS.map((sec, idx) => {
                const IconComponent = sec.icon;
                const isCurrent = idx === currentStep;
                return (
                  <button
                    key={sec.id}
                    type="button"
                    className={`step-tab-btn ${isCurrent ? "current" : ""}`}
                    onClick={() => setCurrentStep(idx)}
                  >
                    <span className="step-num">{idx + 1}</span>
                    <IconComponent size="{14}"/>
                    <span className="step-txt">{sec.label}</span>
                  </button>
                );
              })}
            </div>

            {/* FORM INPUTS */}
            <div className="res-form-scroll-pane">
              {/* 1. PERSONAL */}
              {currentStep === 0 && (
                <div className="section-form-box">
                  <div className="section-title-wrap">
                    <h3>1. Personal Details</h3>
                    <p>Enter contact details for recruiter communication.</p>
                  </div>
                  <div className="inputs-2col-grid">
                    <div className="input-field col-span-2">
                      <label>Full Legal Name</label>
                      <input
                        type="text"
                        value={resume.personal?.fullName || ""}
                        onChange={(e) => handlePersonalChange("fullName", e.target.value)}
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="input-field">
                      <label>Email Address</label>
                      <input
                        type="email"
                        value={resume.personal?.email || ""}
                        onChange={(e) => handlePersonalChange("email", e.target.value)}
                        placeholder="john.doe@example.com"
                      />
                    </div>
                    <div className="input-field">
                      <label>Phone Number</label>
                      <input
                        type="text"
                        value={resume.personal?.phone || ""}
                        onChange={(e) => handlePersonalChange("phone", e.target.value)}
                        placeholder="+91 9876543210"
                      />
                    </div>
                    <div className="input-field">
                      <label>City & Country</label>
                      <input
                        type="text"
                        value={resume.personal?.location || ""}
                        onChange={(e) => handlePersonalChange("location", e.target.value)}
                        placeholder="Bengaluru, India"
                      />
                    </div>
                    <div className="input-field">
                      <label>LinkedIn URL</label>
                      <input
                        type="text"
                        value={resume.personal?.linkedin || ""}
                        onChange={(e) => handlePersonalChange("linkedin", e.target.value)}
                        placeholder="[linkedin.com/in/johndoe](https://linkedin.com/in/johndoe)"
                      />
                    </div>
                    <div className="input-field">
                      <label>GitHub URL</label>
                      <input
                        type="text"
                        value={resume.personal?.github || ""}
                        onChange={(e) => handlePersonalChange("github", e.target.value)}
                        placeholder="[github.com/johndoe](https://github.com/johndoe)"
                      />
                    </div>
                    <div className="input-field">
                      <label>Portfolio URL</label>
                      <input
                        type="text"
                        value={resume.personal?.website || ""}
                        onChange={(e) => handlePersonalChange("website", e.target.value)}
                        placeholder="johndoe.dev"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 2. SUMMARY */}
              {currentStep === 1 && (
                <div className="section-form-box">
                  <div className="section-title-wrap flex-between">
                    <div>
                      <h3>2. Professional Summary</h3>
                      <p>Write 2-4 sentences highlighting your background and strengths.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-ai-enhance"
                      disabled={enhancing}
                      onClick={() =>
                        handleAiEnhance("summary", resume.summary, (res) =>
                          setResume((prev) => ({ ...prev, summary: res }))
                        )
                      }
                    >
                      {enhancing ? <Loader2 className="spinner-icon" size="{13}"/> : <Sparkles size="{13}"/>}
                      <span>Enhance with AI</span>
                    </button>
                  </div>
                  <div className="input-field">
                    <textarea
                      rows={8}
                      value={resume.summary || ""}
                      onChange={(e) => setResume((prev) => ({ ...prev, summary: e.target.value }))}
                      placeholder="Results-oriented Software Engineer proficient in Java, Spring Boot, and PostgreSQL..."
                    />
                  </div>
                </div>
              )}

              {/* 3. TECHNICAL SKILLS */}
              {currentStep === 2 && (
                <div className="section-form-box">
                  <div className="section-title-wrap">
                    <h3>3. Technical Skills (Comma Separated)</h3>
                    <p>Enter items separated by commas to format into ATS skill lines.</p>
                  </div>
                  <div className="inputs-1col-stack">
                    <div className="input-field">
                      <label>Programming Languages</label>
                      <input
                        type="text"
                        value={skillInputs.Languages || ""}
                        onChange={(e) => handleSkillChange("Languages", e.target.value)}
                        placeholder="Java, JavaScript, TypeScript, SQL, Python"
                      />
                    </div>
                    <div className="input-field">
                      <label>Frameworks, Libraries & Tools</label>
                      <input
                        type="text"
                        value={skillInputs["Frameworks & Tools"] || ""}
                        onChange={(e) => handleSkillChange("Frameworks & Tools", e.target.value)}
                        placeholder="Spring Boot, React, Git, Maven, Docker"
                      />
                    </div>
                    <div className="input-field">
                      <label>Databases & Cloud</label>
                      <input
                        type="text"
                        value={skillInputs.Databases || ""}
                        onChange={(e) => handleSkillChange("Databases", e.target.value)}
                        placeholder="PostgreSQL, MySQL, MongoDB, AWS S3"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 4. EDUCATION */}
              {currentStep === 3 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>4. Education History</h3>
                      <p>Add your degrees and academic qualifications.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("education", {
                          institution: "",
                          degree: "",
                          field: "",
                          startDate: "",
                          endDate: "",
                          grade: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Degree</span>
                    </button>
                  </div>

                  {(resume.education || []).map((edu, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Education #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("education", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field col-span-2">
                          <label>Institution / University Name</label>
                          <input
                            type="text"
                            value={edu.institution || ""}
                            onChange={(e) => handleArrayItemChange("education", idx, "institution", e.target.value)}
                            placeholder="Visvesvaraya Technological University"
                          />
                        </div>
                        <div className="input-field">
                          <label>Degree (e.g. B.E.)</label>
                          <input
                            type="text"
                            value={edu.degree || ""}
                            onChange={(e) => handleArrayItemChange("education", idx, "degree", e.target.value)}
                            placeholder="Bachelor of Engineering"
                          />
                        </div>
                        <div className="input-field">
                          <label>Branch / Major (e.g. CSE)</label>
                          <input
                            type="text"
                            value={edu.field || ""}
                            onChange={(e) => handleArrayItemChange("education", idx, "field", e.target.value)}
                            placeholder="Computer Science & Engineering"
                          />
                        </div>
                        <div className="input-field">
                          <label>Graduation Dates</label>
                          <input
                            type="text"
                            value={edu.startDate ? `${edu.startDate} - ${edu.endDate || "Present"}` : edu.dates || ""}
                            onChange={(e) => handleArrayItemChange("education", idx, "dates", e.target.value)}
                            placeholder="2022 - 2026"
                          />
                        </div>
                        <div className="input-field">
                          <label>CGPA / Percentage</label>
                          <input
                            type="text"
                            value={edu.grade || ""}
                            onChange={(e) => handleArrayItemChange("education", idx, "grade", e.target.value)}
                            placeholder="CGPA: 8.75 / 10"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 5. INTERNSHIPS */}
              {currentStep === 4 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>5. Internship Experience</h3>
                      <p>Showcase company internships and practical technical work.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("internships", {
                          role: "",
                          company: "",
                          location: "",
                          startDate: "",
                          endDate: "",
                          description: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Internship</span>
                    </button>
                  </div>

                  {(resume.internships || []).map((intern, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Internship #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("internships", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Internship Role</label>
                          <input
                            type="text"
                            value={intern.role || ""}
                            onChange={(e) => handleArrayItemChange("internships", idx, "role", e.target.value)}
                            placeholder="Java Development Intern"
                          />
                        </div>
                        <div className="input-field">
                          <label>Company</label>
                          <input
                            type="text"
                            value={intern.company || ""}
                            onChange={(e) => handleArrayItemChange("internships", idx, "company", e.target.value)}
                            placeholder="Oasis Infobyte"
                          />
                        </div>
                        <div className="input-field">
                          <label>Location</label>
                          <input
                            type="text"
                            value={intern.location || ""}
                            onChange={(e) => handleArrayItemChange("internships", idx, "location", e.target.value)}
                            placeholder="Remote"
                          />
                        </div>
                        <div className="input-field">
                          <label>Dates</label>
                          <input
                            type="text"
                            value={intern.startDate ? `${intern.startDate} - ${intern.endDate || "Present"}` : intern.dates || ""}
                            onChange={(e) => handleArrayItemChange("internships", idx, "dates", e.target.value)}
                            placeholder="Aug 2026 - Sep 2026"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <div className="label-with-ai">
                            <label>Bullet Points</label>
                            <button
                              type="button"
                              className="btn-ai-bullet"
                              disabled={enhancing}
                              onClick={() =>
                                handleAiEnhance(
                                  "internship",
                                  intern.description,
                                  (res) => handleArrayItemChange("internships", idx, "description", res),
                                  intern.role
                                )
                              }
                            >
                              <Sparkles size="{11}"/>
                              <span>Enhance Bullets</span>
                            </button>
                          </div>
                          <textarea
                            rows={4}
                            value={intern.description || ""}
                            onChange={(e) => handleArrayItemChange("internships", idx, "description", e.target.value)}
                            placeholder="• Built ATM interface using Java Core and OOP concepts&#10;• Implemented Digital Library Management with MVC design"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 6. WORK EXPERIENCE */}
              {currentStep === 5 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>6. Work Experience</h3>
                      <p>Detail full-time or part-time engineering roles.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("experience", {
                          role: "",
                          company: "",
                          location: "",
                          startDate: "",
                          endDate: "",
                          description: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Position</span>
                    </button>
                  </div>

                  {(resume.experience || []).map((exp, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Position #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("experience", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Job Title / Role</label>
                          <input
                            type="text"
                            value={exp.role || ""}
                            onChange={(e) => handleArrayItemChange("experience", idx, "role", e.target.value)}
                            placeholder="Junior Backend Developer"
                          />
                        </div>
                        <div className="input-field">
                          <label>Company Name</label>
                          <input
                            type="text"
                            value={exp.company || ""}
                            onChange={(e) => handleArrayItemChange("experience", idx, "company", e.target.value)}
                            placeholder="Tech Solutions Ltd"
                          />
                        </div>
                        <div className="input-field">
                          <label>Location</label>
                          <input
                            type="text"
                            value={exp.location || ""}
                            onChange={(e) => handleArrayItemChange("experience", idx, "location", e.target.value)}
                            placeholder="Bengaluru, India"
                          />
                        </div>
                        <div className="input-field">
                          <label>Dates / Duration</label>
                          <input
                            type="text"
                            value={exp.startDate ? `${exp.startDate} - ${exp.endDate || "Present"}` : exp.dates || ""}
                            onChange={(e) => handleArrayItemChange("experience", idx, "dates", e.target.value)}
                            placeholder="Oct 2025 - Present"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <div className="label-with-ai">
                            <label>Bullet Points</label>
                            <button
                              type="button"
                              className="btn-ai-bullet"
                              disabled={enhancing}
                              onClick={() =>
                                handleAiEnhance(
                                  "experience",
                                  exp.description,
                                  (res) => handleArrayItemChange("experience", idx, "description", res),
                                  exp.role
                                )
                              }
                            >
                              <Sparkles size="{11}"/>
                              <span>Enhance Bullets</span>
                            </button>
                          </div>
                          <textarea
                            rows={4}
                            value={exp.description || ""}
                            onChange={(e) => handleArrayItemChange("experience", idx, "description", e.target.value)}
                            placeholder="• Engineered stateless authentication using Spring Security 6 & JWT&#10;• Reduced latency by 20% by indexing queries in PostgreSQL"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 7. PROJECTS */}
              {currentStep === 6 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>7. Technical Projects</h3>
                      <p>Showcase projects with measurable tech impact.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("projects", {
                          name: "",
                          technologies: "",
                          link: "",
                          description: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Project</span>
                    </button>
                  </div>

                  {(resume.projects || []).map((proj, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Project #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("projects", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Project Title</label>
                          <input
                            type="text"
                            value={proj.name || ""}
                            onChange={(e) => handleArrayItemChange("projects", idx, "name", e.target.value)}
                            placeholder="Smart Agri-Warehouse Management"
                          />
                        </div>
                        <div className="input-field">
                          <label>Tech Stack</label>
                          <input
                            type="text"
                            value={proj.technologies || ""}
                            onChange={(e) => handleArrayItemChange("projects", idx, "technologies", e.target.value)}
                            placeholder="Java, Spring Boot, React, PostgreSQL"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <label>Project / Repository Link (Optional)</label>
                          <input
                            type="text"
                            value={proj.link || ""}
                            onChange={(e) => handleArrayItemChange("projects", idx, "link", e.target.value)}
                            placeholder="[https://github.com/anusha/agri-warehouse](https://github.com/anusha/agri-warehouse)"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <div className="label-with-ai">
                            <label>Bullet Points</label>
                            <button
                              type="button"
                              className="btn-ai-bullet"
                              disabled={enhancing}
                              onClick={() =>
                                handleAiEnhance(
                                  "project",
                                  proj.description,
                                  (res) => handleArrayItemChange("projects", idx, "description", res),
                                  proj.technologies
                                )
                              }
                            >
                              <Sparkles size="{11}"/>
                              <span>Enhance Bullets</span>
                            </button>
                          </div>
                          <textarea
                            rows={4}
                            value={proj.description || ""}
                            onChange={(e) => handleArrayItemChange("projects", idx, "description", e.target.value)}
                            placeholder="• Built automated threshold monitoring system for warehouse sensors&#10;• Created PDF export utility using PDFBox 3.x"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 8. CERTIFICATIONS */}
              {currentStep === 7 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>8. Certifications</h3>
                      <p>Add credentials and certificates.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("certifications", {
                          name: "",
                          issuer: "",
                          date: "",
                          credentialId: "",
                          url: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Certificate</span>
                    </button>
                  </div>

                  {(resume.certifications || []).map((cert, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Certificate #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("certifications", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field col-span-2">
                          <label>Certification Name</label>
                          <input
                            type="text"
                            value={cert.name || (typeof cert === "string" ? cert : "")}
                            onChange={(e) => handleArrayItemChange("certifications", idx, "name", e.target.value)}
                            placeholder="AWS Certified Cloud Practitioner"
                          />
                        </div>
                        <div className="input-field">
                          <label>Issuer</label>
                          <input
                            type="text"
                            value={cert.issuer || ""}
                            onChange={(e) => handleArrayItemChange("certifications", idx, "issuer", e.target.value)}
                            placeholder="Amazon Web Services"
                          />
                        </div>
                        <div className="input-field">
                          <label>Date / Year</label>
                          <input
                            type="text"
                            value={cert.date || ""}
                            onChange={(e) => handleArrayItemChange("certifications", idx, "date", e.target.value)}
                            placeholder="2026"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <label>Verification Link (Optional)</label>
                          <input
                            type="text"
                            value={cert.url || ""}
                            onChange={(e) => handleArrayItemChange("certifications", idx, "url", e.target.value)}
                            placeholder="[https://aws.amazon.com/verify/](https://aws.amazon.com/verify/)..."
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 9. ACHIEVEMENTS */}
              {currentStep === 8 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>9. Honors & Achievements</h3>
                      <p>Showcase hackathon awards and competition wins.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("achievements", {
                          title: "",
                          issuer: "",
                          description: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Achievement</span>
                    </button>
                  </div>

                  {(resume.achievements || []).map((ach, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Achievement #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("achievements", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Honor Title</label>
                          <input
                            type="text"
                            value={ach.title || ""}
                            onChange={(e) => handleArrayItemChange("achievements", idx, "title", e.target.value)}
                            placeholder="Selected for NAIN 2.0 State Incubation"
                          />
                        </div>
                        <div className="input-field">
                          <label>Organization / Event</label>
                          <input
                            type="text"
                            value={ach.issuer || ""}
                            onChange={(e) => handleArrayItemChange("achievements", idx, "issuer", e.target.value)}
                            placeholder="Government of Karnataka"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <label>Description (Optional)</label>
                          <input
                            type="text"
                            value={ach.description || ""}
                            onChange={(e) => handleArrayItemChange("achievements", idx, "description", e.target.value)}
                            placeholder="Received project funding for Smart Warehouse prototype"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 10. INVOLVEMENT */}
              {currentStep === 9 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>10. Leadership & Involvement</h3>
                      <p>Highlight student clubs, leadership, and volunteer work.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("involvement", {
                          role: "",
                          organization: "",
                          year: "",
                          description: "",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Activity</span>
                    </button>
                  </div>

                  {(resume.involvement || []).map((inv, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Activity #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("involvement", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Position / Role</label>
                          <input
                            type="text"
                            value={inv.role || ""}
                            onChange={(e) => handleArrayItemChange("involvement", idx, "role", e.target.value)}
                            placeholder="Technical Club Lead"
                          />
                        </div>
                        <div className="input-field">
                          <label>Organization / Society</label>
                          <input
                            type="text"
                            value={inv.organization || ""}
                            onChange={(e) => handleArrayItemChange("involvement", idx, "organization", e.target.value)}
                            placeholder="Student Developer Group"
                          />
                        </div>
                        <div className="input-field">
                          <label>Year / Duration</label>
                          <input
                            type="text"
                            value={inv.year || ""}
                            onChange={(e) => handleArrayItemChange("involvement", idx, "year", e.target.value)}
                            placeholder="2025 - 2026"
                          />
                        </div>
                        <div className="input-field col-span-2">
                          <label>Contributions</label>
                          <textarea
                            rows={3}
                            value={inv.description || ""}
                            onChange={(e) => handleArrayItemChange("involvement", idx, "description", e.target.value)}
                            placeholder="Led technical workshops and mentored junior engineering students."
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 11. LANGUAGES */}
              {currentStep === 10 && (
                <div className="section-form-box">
                  <div className="section-title-flex">
                    <div>
                      <h3>11. Languages</h3>
                      <p>Specify the languages you speak and your proficiency.</p>
                    </div>
                    <button
                      type="button"
                      className="btn-add-repeat"
                      onClick={() =>
                        addArrayItem("languages", {
                          name: "",
                          proficiency: "Fluent",
                        })
                      }
                    >
                      <Plus size="{14}"/>
                      <span>Add Language</span>
                    </button>
                  </div>

                  {(resume.languages || []).map((lang, idx) => (
                    <div key={idx} className="repeatable-card-unit">
                      <div className="card-top-header">
                        <span className="card-tag">Language #{idx + 1}</span>
                        <button type="button" className="btn-del-unit" onClick={() => removeArrayItem("languages", idx)}>
                          <Trash2 size="{14}"/>
                        </button>
                      </div>
                      <div className="inputs-2col-grid">
                        <div className="input-field">
                          <label>Language Name</label>
                          <input
                            type="text"
                            value={lang.name || (typeof lang === "string" ? lang : "")}
                            onChange={(e) => handleArrayItemChange("languages", idx, "name", e.target.value)}
                            placeholder="English"
                          />
                        </div>
                        <div className="input-field">
                          <label>Proficiency</label>
                          <select
                            value={lang.proficiency || "Fluent"}
                            onChange={(e) => handleArrayItemChange("languages", idx, "proficiency", e.target.value)}
                          >
                            <option value="Native">Native</option>
                            <option value="Fluent">Fluent</option>
                            <option value="Professional">Professional</option>
                            <option value="Conversational">Conversational</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* BOTTOM NAV BAR */}
            <footer className="res-step-footer-bar">
              <button
                type="button"
                className="step-btn-nav prev-btn"
                disabled={currentStep === 0}
                onClick={handlePrevious}
              >
                <ArrowLeft size="{15}"/>
                <span>Previous</span>
              </button>

              <div className="footer-right-buttons">
                {currentStep < SECTIONS.length - 1 && (
                  <button type="button" className="step-btn-nav skip-btn" onClick={handleSkip}>
                    <span>Skip</span>
                    <SkipForward size="{14}"/>
                  </button>
                )}

                <button type="button" className="step-btn-nav next-btn" onClick={handleNext}>
                  <span>{currentStep === SECTIONS.length - 1 ? "Finish & Save" : "Save & Next"}</span>
                  <ArrowRight size="{15}"/>
                </button>
              </div>
            </footer>
          </div>
        )}

        {/* RIGHT COLUMN: PREVIEW */}
        {(viewMode === "preview" || viewMode === "both") && (
          <div className="res-preview-column">
            <div className="res-paper-scale-box" ref={printRef}>
              <ResumePreview resume="{resume}"/>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}