import React, { useState } from 'react';
import { Plus, X, Trash2, Cpu } from 'lucide-react';
import './SectionStyles.css';

export default function SkillsSection({ data = {}, onChange }) {
  const [newCategoryName, setNewCategoryName] = useState("");
  const [activeInput, setActiveInput] = useState({});

  // Ensure default categories exist if skills object is empty
  const skillCategories = Object.keys(data).length > 0
    ? data
    : {
        "Languages": ["Java", "SQL", "JavaScript"],
        "Backend & Frameworks": ["Spring Boot", "REST APIs", "Hibernate"],
        "Frontend": ["React.js", "HTML5", "CSS3"],
        "Tools & Cloud": ["Git", "Docker", "Postman"]
      };

  const handleAddCategory = (e) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    const cat = newCategoryName.trim();
    if (skillCategories[cat]) return;

    onChange({
      ...skillCategories,
      [cat]: []
    });
    setNewCategoryName("");
  };

  const handleRemoveCategory = (catName) => {
    const copy = { ...skillCategories };
    delete copy[catName];
    onChange(copy);
  };

  const handleAddSkillTag = (catName) => {
    const val = (activeInput[catName] || "").trim();
    if (!val) return;

    const currentList = skillCategories[catName] || [];
    if (!currentList.includes(val)) {
      onChange({
        ...skillCategories,
        [catName]: [...currentList, val]
      });
    }

    setActiveInput({ ...activeInput, [catName]: "" });
  };

  const handleRemoveSkillTag = (catName, tagToRemove) => {
    const currentList = skillCategories[catName] || [];
    onChange({
      ...skillCategories,
      [catName]: currentList.filter((item) => item !== tagToRemove)
    });
  };

  return (
    <div className="dynamic-skills-panel">
      {/* Category List */}
      <div className="skill-categories-stack">
        {Object.entries(skillCategories).map(([catName, tags]) => (
          <div key={catName} className="skill-category-box">
            <div className="skill-category-header">
              <span className="category-title">
                <Cpu size={14} />
                <span>{catName}</span>
              </span>
              <button
                type="button"
                className="btn-delete-cat"
                onClick={() => handleRemoveCategory(catName)}
                title="Remove category"
              >
                <Trash2 size={14} />
              </button>
            </div>

            {/* Tags Container */}
            <div className="skills-tag-wrap">
              {tags.map((tag) => (
                <span key={tag} className="skill-pill">
                  <span>{tag}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSkillTag(catName, tag)}
                    className="btn-remove-tag"
                  >
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>

            {/* Add Tag Inline Form */}
            <div className="add-tag-row">
              <input
                type="text"
                placeholder={`Add skill in ${catName}...`}
                value={activeInput[catName] || ""}
                onChange={(e) =>
                  setActiveInput({ ...activeInput, [catName]: e.target.value })
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddSkillTag(catName);
                  }
                }}
              />
              <button
                type="button"
                className="btn-tag-add"
                onClick={() => handleAddSkillTag(catName)}
              >
                Add
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add New Custom Category Form */}
      <div className="add-category-bar">
        <input
          type="text"
          placeholder="New Category Name (e.g. Databases, Cloud & DevOps)..."
          value={newCategoryName}
          onChange={(e) => setNewCategoryName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              handleAddCategory(e);
            }
          }}
        />
        <button
          type="button"
          className="btn-create-category"
          onClick={handleAddCategory}
        >
          <Plus size={15} />
          <span>Add Category</span>
        </button>
      </div>
    </div>
  );
}