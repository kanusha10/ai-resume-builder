import React from "react";
import "./ResumePreview.css";

function renderBullets(text) {
  if (!text || !text.trim()) return null;

  const items = text
    .split(/\r?\n/)
    .map((line) => line.replace(/^[\s•*\-–▪›>]+/, "").trim())
    .filter(Boolean);

  if (items.length === 0) return null;

  return (
    <ul className="resume-bullets">
      {items.map((it, idx) => (
        <li key={idx}>{it}</li>
      ))}
    </ul>
  );
}

export default function ResumePreview({ resume }) {
  const {
    personal = {},
    summary = "",
    education = [],
    internships = [],
    experience = [],
    projects = [],
    skills = {},
    certifications = [],
    languages = [],
  } = resume || {};

  const currentColor = resume.color || resume.primaryColor || "#0f172a";
  const template = resume.template || "emma";

  return (
    <div className="preview-wrap">
      <div
        id="resume-canvas"
        className={`resume-canvas tmpl-${template}`}
        style={{ "--primary-theme-color": currentColor }}
      >
        {/* HEADER */}
        <header className="resume-hdr">
          <h1 className="hdr-name">{personal.fullName || "Your Full Name"}</h1>
          {resume.role && <div className="hdr-role">{resume.role}</div>}

          <div className="hdr-contact">
            {personal.location && <span>{personal.location}</span>}
            {personal.phone && <span>• {personal.phone}</span>}
            {personal.email && (
              <span>
                • <a href={`mailto:${personal.email}`}>{personal.email}</a>
              </span>
            )}
            {personal.linkedin && (
              <span>
                • <a href={personal.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
              </span>
            )}
            {personal.github && (
              <span>
                • <a href={personal.github} target="_blank" rel="noreferrer">GitHub</a>
              </span>
            )}
            {personal.website && (
              <span>
                • <a href={personal.website} target="_blank" rel="noreferrer">Portfolio</a>
              </span>
            )}
          </div>
        </header>

        {/* SUMMARY */}
        {summary && (
          <section className="resume-block">
            <h2 className="block-title">Summary</h2>
            <p className="summary-paragraph">{summary}</p>
          </section>
        )}

        {/* TECHNICAL SKILLS */}
        {skills && Object.keys(skills).length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Technical Skills</h2>
            <div className="skills-group">
              {Object.entries(skills).map(
                ([cat, items]) =>
                  Array.isArray(items) && items.length > 0 && (
                    <div key={cat} className="skill-row">
                      <strong className="skill-cat">{cat}:</strong>{" "}
                      <span className="skill-values">{items.join(", ")}</span>
                    </div>
                  )
              )}
            </div>
          </section>
        )}

        {/* WORK EXPERIENCE */}
        {experience && experience.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Work Experience</h2>
            {experience.map((exp, idx) => (
              <div key={idx} className="entry-row">
                <div className="entry-head">
                  <span>
                    <strong className="entry-title">{exp.role || "Job Title"}</strong>
                    {exp.company && <span className="entry-org"> | {exp.company}</span>}
                  </span>
                  <span className="entry-dates">
                    {[exp.startDate, exp.endDate].filter(Boolean).join(" - ") || exp.dates}
                  </span>
                </div>
                {exp.location && <div className="entry-sub">{exp.location}</div>}
                {renderBullets(exp.description)}
              </div>
            ))}
          </section>
        )}

        {/* INTERNSHIPS */}
        {internships && internships.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Internships</h2>
            {internships.map((int, idx) => (
              <div key={idx} className="entry-row">
                <div className="entry-head">
                  <span>
                    <strong className="entry-title">{int.role || "Intern"}</strong>
                    {int.company && <span className="entry-org"> | {int.company}</span>}
                  </span>
                  <span className="entry-dates">
                    {[int.startDate, int.endDate].filter(Boolean).join(" - ") || int.dates}
                  </span>
                </div>
                {int.location && <div className="entry-sub">{int.location}</div>}
                {renderBullets(int.description)}
              </div>
            ))}
          </section>
        )}

        {/* PROJECTS */}
        {projects && projects.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Projects</h2>
            {projects.map((proj, idx) => (
              <div key={idx} className="entry-row">
                <div className="entry-head">
                  <span>
                    <strong className="entry-title">{proj.name || "Project Title"}</strong>
                    {proj.technologies && <span className="entry-tech"> ({proj.technologies})</span>}
                  </span>
                  {proj.link && (
                    <a href={proj.link} target="_blank" rel="noreferrer" className="entry-link">
                      Link
                    </a>
                  )}
                </div>
                {renderBullets(proj.description)}
              </div>
            ))}
          </section>
        )}

        {/* EDUCATION */}
        {education && education.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Education</h2>
            {education.map((edu, idx) => (
              <div key={idx} className="entry-row">
                <div className="entry-head">
                  <div>
                    <strong className="entry-title">{edu.institution}</strong>
                    <div className="entry-sub">
                      {[edu.degree, edu.field].filter(Boolean).join(" in ")}
                    </div>
                  </div>
                  <span className="entry-dates">
                    {[edu.startDate, edu.endDate].filter(Boolean).join(" - ") || edu.dates}
                  </span>
                </div>
                {edu.grade && <div className="entry-grade">CGPA / Score: {edu.grade}</div>}
              </div>
            ))}
          </section>
        )}

        {/* CERTIFICATIONS */}
        {certifications && certifications.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Certifications</h2>
            <ul className="resume-bullets">
              {certifications.map((cert, idx) => (
                <li key={idx}>
                  {typeof cert === "string" ? cert : (
                    <span>
                      <strong>{cert.name}</strong>
                      {cert.issuer && ` – ${cert.issuer}`}
                      {cert.date && ` (${cert.date})`}
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* LANGUAGES */}
        {languages && languages.length > 0 && (
          <section className="resume-block">
            <h2 className="block-title">Languages</h2>
            <div className="languages-inline">
              {languages
                .map((l) => (typeof l === "string" ? l : `${l.name} (${l.proficiency || "Fluent"})`))
                .join(" • ")}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}